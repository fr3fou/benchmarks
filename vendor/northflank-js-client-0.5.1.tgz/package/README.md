## Northflank API js-client package
Node.js client for the Northflank platform based on the Northflank public API.

*Visit our website [www.northflank.com](https://www.northflank.com)*

*Full documentation on [https://northflank.com/docs/v1/api/use-the-javascript-client](https://northflank.com/docs/v1/api/use-the-javascript-client)*

*Also use the Northflank command line interface (CLI): [https://www.npmjs.com/package/@northflank/cli](https://www.npmjs.com/package/@northflank/cli)*

Please don’t hesitate to get in touch with us if you have a query or want to 
give some feedback on [https://northflank.com/contact](https://northflank.com/contact)
or email us at [contact@northflank.com](mailto:contact@northflank.com).

### Setup
Add as a dependency to your project with 
```npm i @northflank/js-client``` or ```yarn add @northflank/js-client```.

### Using the package
Example usage: 
```javascript
import { ApiClient, ApiClientInMemoryContextProvider } from '@northflank/js-client';

(async () => {
  // Create context to store credentials.
  const contextProvider = new ApiClientInMemoryContextProvider();
  await contextProvider.addContext({
    name: 'test-context',
    token: '<api-token>', // Use token retrieved from Northflank web interface: Account Settings > API > Tokens > Create API token.
  });

  // Initialize API client.
  const apiClient = new ApiClient(contextProvider);

  // Retrieve list of projects and log to console.
  const projects = (await apiClient.list.projects({})).data.projects;
  console.log(projects);

  // Create a new project.
  const project = await apiClient.create.project({
    data: {
      name: 'test-project',
      region: 'europe-west',
      description: 'test project description',
    },
  });

  // List services in newly created project
  const { services } = (await apiClient.list.services({ parameters: { projectId: project.data.id } })).data;
  console.log(services.map((svc) => svc.name).join(', '));
})();
```
If used with Typescript, full typing support can be leveraged. 

_Supported Node.js versions: 18 or newer_